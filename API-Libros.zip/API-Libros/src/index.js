//importando los paquetes
const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
//importando y configurando dotenv variables de entorno
require("dotenv").config();

//Ejecuntando express y guardando en app
const app = express();

//Agregando cors como un middleware
app.use(cors());
app.use(express.json());

const mongoUri = process.env.MONGODB_URI;

try {
    //Conexion a la base de datos
    mongoose.connect(mongoUri);
    console.log("Conectado a MongoDB Atlas");
} catch (error) {
    console.error("Error de conexion", error)
}

//Darle la estructura a los datos(Libros)
const libroSchema = new mongoose.Schema({
    titulo: String,
    autor: String
});

// Modelo nos permite usar los metodos para el CRUD
const Libro = mongoose.model("Libro", libroSchema);

//Ruta Crear Libros
app.post("/libros", async (req, res) => {
  const libro = new Libro({
    titulo: req.body.titulo,
    autor: req.body.autor,
  });

  try {
    //guardando el libro en la base de datos
    await libro.save();
    res.json(libro);
  } catch (error) {
    res.status(500).send("Error al guardar el libro");
  }
});

//Ruta para listar los libros
app.get("/libros", async (req, res) => {
    try {
        const listaLibros = await Libro.find();
        res.json(listaLibros);
    } catch (error) {
        res.status(500).send("Error al obtener los libros");
    }
})

//Ruta para obtener un libro por su id
app.get("/libros/:id", async (req, res) => {
    try {
        const libro = await Libro.findById(req.params.id);
        if(libro) {
            res.json(libro)
        }else {
            res.status(404).send("Libro no encontrado");
        }
    } catch (error) {
        res.status(500).send("Error al buscar el libro")
    }
})

//delete id         app.delete("/libros/:id"                NUEVO
app.delete("/libros/:id", async (req, res) => {
    try {
        const libro = await Libro.findByIdAndDelete(req.params.id);
        if(libro) {
            res.json(libro)
        }else {
            res.status(404).send("Libro no encontrado");
        }
    } catch (error) {
        res.status(500).send("Error al eliminar el libro")
    }
})

//update id         app.put                                 NUEVO
app.put("/libros/:id", async (req, res) => {
    try {
        const libro = await Libro.findByIdAndUpdate(req.params.id,
        {
            titulo: req.body.titulo,
            autor: req.body.autor,
          },
          { new: true });
        if(libro) {
            res.json(libro)
        }else {
            res.status(404).send("Libro no encontrado");
        }
    } catch (error) {
        res.status(500).send("Error al buscar el libro")
    }
})

//Levantar el servidor de Node
app.listen(3000, () => {
    console.log("Servidor ejecutándose en http://localhost:3000/");
})